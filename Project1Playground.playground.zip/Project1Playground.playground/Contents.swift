import UIKit

var league = [["Name":"Joe Smith", "Height":"42", "Experience":"Yes", "Guardian":"Jim and Jan Smith"], ["Name":"Jill Tanner", "Height":"36", "Experience":"Yes", "Guardian":"Clara Tanner"], ["Name":"Bill Bon", "Height":"36", "Experience":"Yes", "Guardian":"Sara and Jenny Bon"], ["Name":"Eva Gordon", "Height":"45", "Experience":"No", "Guardian":"Wendy and Mike Gordon"], ["Name":"Matt Gill", "Height":"40", "Experience":"No", "Guardian":"Charles and Sylvia Gill"], ["Name":"Kimmy Stein", "Height":"41", "Experience":"No", "Guardian":"Bill and Hillary Stein"], ["Name":"Sammy Adams", "Height":"45", "Experience":"No", "Guardian":"Jeff Adams"], ["Name":"Karl Saygan", "Height":"42", "Experience":"Yes", "Guardian":"Heather Bledsoe"], ["Name":"Suzane Greenberg", "Height":"44", "Experience":"Yes", "Guardian":"Henrietta Dumas"], ["Name":"Sal Dali", "Height":"41", "Experience":"No", "Guardian":"Gala Dali"], ["Name":"Joe Kavalier", "Height":"39", "Experience":"No", "Guardian":"Sam and Elaine Kavalier"], ["Name":"Ben Finkelstein", "Height":"44", "Experience":"No", "Guardian":"Aaron and Jill Finkelstein"], ["Name":"Diego Soto", "Height":"41", "Experience":"Yes", "Guardian":"Robin and Sarika Soto"], ["Name":"Chloe Alaska", "Height":"47", "Experience":"No", "Guardian":"David and Jamie Alaska"], ["Name":"Arnold Willis", "Height":"43", "Experience":"No", "Guardian":"Claire Willis"], ["Name":"Phillip Helm", "Height":"44", "Experience":"Yes", "Guardian":"Thomas Helm and Eva Jones"], ["Name":"Les Clay", "Height":"42", "Experience":"Yes", "Guardian":"Wynonna Brown"], ["Name":"Herschel Krustofski", "Height":"45", "Experience":"Yes","Guardian":"Hyman and Rachel Krustofski"]]

    
  
    // MARK: - Player Roster

    
    var teamDragons = [[String:String]]()
    
    var teamSharks = [[String:String]]()
    
    var teamRaptors = [[String:String]]()


    var letters = [String]()
    
    //   MARK: - Divide the Teams
    
    var experiencedPlayers = [[String:String]]()
    
    var inexperiencedPlayers = [[String:String]]()


var raptorsPlayersEntry: Bool = true
var dragonsPlayersEntry: Bool = false
var sharksPlayersEntry: Bool = false
var playerAlreadyAdded: Bool = false
    
    func divideXPLevel() {
        
        for player in league {
          
            for (_, value) in player {
                switch value {
                case "No": inexperiencedPlayers.append(player)
                case "Yes": experiencedPlayers.append(player)
                default: break
                    
                }
                
            }
            
        }
      
    }
    
    func divideTeams(firstString: [[String:String]], secondString: [[String:String]]) {

        var tempCollection = [String:String]()
        
        for teams in firstString {
            playerAlreadyAdded = false
    
            if raptorsPlayersEntry == true && playerAlreadyAdded == false {
                tempCollection = teams
                tempCollection ["Team"] = "Raptors"
                tempCollection ["Time"] = "March 18, 1pm"
                teamRaptors.append(tempCollection)
                raptorsPlayersEntry = false
                dragonsPlayersEntry = true
                playerAlreadyAdded = true
                
            }
            
            if dragonsPlayersEntry == true && playerAlreadyAdded == false {
                tempCollection = teams
                tempCollection ["Team"] = "Dragons"
                tempCollection ["Time"] = "March 17, 1pm"
                teamDragons.append(tempCollection)
                dragonsPlayersEntry = false
                sharksPlayersEntry = true
                playerAlreadyAdded = true
            }
            if sharksPlayersEntry == true && playerAlreadyAdded == false {
                tempCollection = teams
                tempCollection ["Team"] = "Sharks"
                tempCollection ["Time"] = "March 17, 3pm"
                teamSharks.append(tempCollection)
                sharksPlayersEntry = false
                raptorsPlayersEntry = true
                playerAlreadyAdded = true
            }
        }
            
            for teams in secondString {
                playerAlreadyAdded = false
                
                if raptorsPlayersEntry == true && playerAlreadyAdded == false {
                    tempCollection = teams
                    tempCollection ["Team"] = "Raptors"
                    tempCollection ["Time"] = "March 18, 1pm"
                    teamRaptors.append(tempCollection)
                    raptorsPlayersEntry = false
                    dragonsPlayersEntry = true
                    playerAlreadyAdded = true
                    
                }
                
                if dragonsPlayersEntry == true && playerAlreadyAdded == false {
                    tempCollection = teams
                    tempCollection ["Team"] = "Dragons"
                    tempCollection ["Time"] = "March 17, 1pm"
                    teamDragons.append(tempCollection)
                    dragonsPlayersEntry = false
                    sharksPlayersEntry = true
                    playerAlreadyAdded = true
                }
                if sharksPlayersEntry == true && playerAlreadyAdded == false {
                    tempCollection = teams
                    tempCollection ["Team"] = "Sharks"
                    tempCollection ["Time"] = "March 17, 3pm"
                    teamSharks.append(tempCollection)
                    sharksPlayersEntry = false
                    raptorsPlayersEntry = true
                    playerAlreadyAdded = true
                }
          
            
         
            
        }
       
        
//        print("Inexperienced Players")
//        print(inexperiencedPlayers)
//        print("experienced Players")
//        print(experiencedPlayers)
        print("The Raptors")
        print(teamRaptors)
        print("The Sharks")
        print(teamSharks)
        print("The Dragons")
        print(teamDragons)
            
        }

    func inform(teamDragonsGuardian dragons: [[String:String]], teamSharksGuardian sharks: [[String:String]], teamRaptorsGuardian raptors: [[String:String]]) {
     
        for message in dragons {
        
            letters.append("Hello, \(String(describing: message["Guardian"])). Your child, \(message["Name"]), has been placed on team \(message["Team"]) and you should attend. Date and time are: \(message["Time"]).")
            
        }
        
        for message in sharks {

           letters.append("Hello, \(String(describing: message["Guardian"])). Your child, \(message["Name"]), has been placed on team \(message["Team"]) and you should attend. Date and time are: \(message["Time"]).")

        }

        for message in raptors {

            letters.append("Hello, \(String(describing: message["Guardian"])). Your child, \(message["Name"]), has been placed on team \(message["Team"]) and you should attend. Date and time are: \(message["Time"]).")

        }
        print("Letters")
        print(letters)
    }
    
        divideXPLevel()
        divideTeams(firstString: experiencedPlayers, secondString: inexperiencedPlayers)
        inform(teamDragonsGuardian: teamDragons, teamSharksGuardian: teamSharks, teamRaptorsGuardian: teamRaptors)

    
    
    
    
    
    
    
    
    
    
    
    

